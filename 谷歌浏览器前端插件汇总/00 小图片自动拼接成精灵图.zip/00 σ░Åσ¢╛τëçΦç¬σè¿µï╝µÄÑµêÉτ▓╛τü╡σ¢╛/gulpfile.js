var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
//png
gulp.task('png', function () {
  gulp.src('./src/*.png')
    .pipe($.spritesmith({
      imgName: 'icon.png',
      cssName: 'icon.css',
      cssTemplate: './src/png_template.hbs'
    }))
    .pipe(gulp.dest('dist/png'));
});
gulp.task('default', ['png']);
