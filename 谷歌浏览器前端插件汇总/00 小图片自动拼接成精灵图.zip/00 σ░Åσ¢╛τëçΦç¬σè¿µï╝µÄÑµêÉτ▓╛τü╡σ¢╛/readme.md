# 小图标处理demo

node.js：v4.4.5 

原文地址：[《前端处理小图标的那些解决方案（图文实操）》](http://yalishizhude.github.io/2016/10/27/icon/)

![总结](./summary.png)
